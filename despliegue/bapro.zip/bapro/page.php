<?php get_header(); the_post(); ?>
<section class="phero pbg"><div class="wrap"><h1><?php the_title(); ?></h1></div></section>
<section class="sec pbg" style="padding-top:0"><div class="wrap"><div class="prose" style="max-width:820px"><?php the_content(); ?></div></div></section>
<?php get_footer(); ?>
