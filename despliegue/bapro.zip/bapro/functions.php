<?php
/** Tema Fundación Banco Provincia. El diseño vive en assets/ (exportado del boceto aprobado); acá se conecta con WordPress. */
if (!defined('ABSPATH')) exit;
define('BAPRO_T', get_template_directory()); define('BAPRO_TU', get_template_directory_uri());
require_once BAPRO_T . '/inc/plantilla.php';
add_action('after_setup_theme', function () {
    add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('html5', ['comment-form', 'comment-list', 'search-form', 'gallery', 'caption']);
    add_theme_support('responsive-embeds'); add_theme_support('editor-styles');
    register_nav_menus(['principal' => 'Menú principal']);
    add_image_size('tarjeta', 900, 1100, true); add_image_size('ancha', 1600, 900, true); add_image_size('cuadrada', 600, 600, true);
    load_theme_textdomain('bapro');
});
add_action('wp_enqueue_scripts', function () {
    $v = filemtime(BAPRO_T . '/assets/sitio.css');
    wp_enqueue_style('bapro-fuente', BAPRO_TU . '/assets/fuentes.css', [], $v); // Encode Sans servida desde el sitio, sin pedirle nada a Google
    wp_enqueue_style('bapro-sitio', BAPRO_TU . '/assets/sitio.css', ['bapro-fuente'], $v);
    wp_enqueue_style('bapro-tema', get_stylesheet_uri(), ['bapro-sitio'], $v);
    wp_enqueue_script('bapro-sitio', BAPRO_TU . '/assets/sitio.js', [], $v, true);
    if (is_singular() && comments_open()) wp_enqueue_script('comment-reply');
});
/** Atributos del <html>: las opciones elegidas (turquesa, menú, mapa, línea) y los valores fijos del diseño aprobado. */
function bapro_html_attrs() {
    $a = ['portada' => 'intro', 'historias' => 'cards', 'programas' => 'tarjetas', 'novedades' => 'lista', 'tono' => 'blanco', 'fondo' => 'silueta', 'datos' => 'liso', 'respira' => 'no', 'boton' => 'si', 'banda' => 'si', 'buscando' => 'no', 'convenios' => bapro_opt('alianzas_estilo'), 'letras' => 'sombra', 'altitulo' => 'arriba', 'bar' => '0', 'turquesa' => bapro_opt('turquesa'), 'menu' => 'formacion', 'mapa' => bapro_opt('mapa'), 'linea' => bapro_opt('linea')];
    $s = ''; foreach ($a as $k => $v) $s .= ' data-' . $k . '="' . esc_attr($v) . '"'; return $s;
}
/** Cabecera: antes de que cargue nada, recarga = intro de nuevo; modo noche elegido por el visitante. */
add_action('wp_head', function () { ?>
<script>(function(){ try{ var nv=performance.getEntriesByType('navigation')[0]; var rl=nv?(nv.type==='reload'):(performance.navigation&&performance.navigation.type===1); if(rl){ history.scrollRestoration='manual'; window.__recarga=true; window.scrollTo(0,0); } }catch(e){} try{ var t=sessionStorage.getItem('h1c-opt-tono'); if(t==='oscuro'||t==='blanco') document.documentElement.setAttribute('data-tono',t); }catch(e){} })();</script>
<?php }, 1);
/* Limpieza de WordPress: sin emojis, sin versiones ni enlaces que no se usan. */
remove_action('wp_head', 'print_emoji_detection_script', 7); remove_action('wp_print_styles', 'print_emoji_styles'); remove_action('wp_head', 'wp_generator'); remove_action('wp_head', 'wlwmanifest_link'); remove_action('wp_head', 'rsd_link');
add_filter('the_generator', '__return_empty_string');
add_action('wp_enqueue_scripts', function () { wp_dequeue_style('wp-block-library'); wp_dequeue_style('global-styles'); wp_dequeue_style('classic-theme-styles'); }, 100);
/* Comentarios: sólo en programas, siempre con aprobación previa, sin enlaces a sitios. */
add_filter('comments_open', function ($abierto, $post_id) { return get_post_type($post_id) === 'programa' ? $abierto : false; }, 10, 2);
add_filter('pre_option_comment_moderation', function () { return 1; });
add_filter('comment_form_default_fields', function ($f) { unset($f['url']); unset($f['cookies']); return $f; });
/* Título de la página de novedades */
add_filter('get_the_archive_title', function ($t) { if (is_home()) return 'Novedades'; if (is_tax('programa_tax')) return single_term_title('', false); return $t; });
/* Extracto corto y limpio */
add_filter('excerpt_length', function () { return 24; }); add_filter('excerpt_more', function () { return '…'; });
/* Imagen por defecto para novedades sin foto: la primera imagen del contenido. */
function bapro_foto($post_id, $tam = 'ancha') {
    if (has_post_thumbnail($post_id)) return get_the_post_thumbnail_url($post_id, $tam);
    if (preg_match('~<img[^>]+src="([^"]+)"~', get_post_field('post_content', $post_id), $m)) return $m[1];
    return '';
}
/* Marcadores "[FALTA: ...]" que vengan en el contenido: en amarillo para quien edita, invisibles para el público. */
add_filter('the_content', function ($c) { return preg_replace_callback('~\[FALTA:\s*([^\]]+)\]~', function ($m) { return is_user_logged_in() ? '<mark class="falta">Falta cargar: ' . esc_html($m[1]) . '</mark>' : ''; }, $c); }, 20);

/* Accesibilidad: ninguna imagen de contenido queda sin texto alternativo. Si en Medios no cargaron uno, se usa el título de la nota o del programa. */
add_filter('wp_get_attachment_image_attributes', function ($a, $att) { if (empty($a['alt'])) { $p = get_post($att->post_parent); $a['alt'] = $p ? get_the_title($p) : ''; } return $a; }, 10, 2);
add_filter('post_thumbnail_html', function ($html, $post_id) { if (strpos($html, 'alt=""') !== false) $html = str_replace('alt=""', 'alt="' . esc_attr(get_the_title($post_id)) . '"', $html); return $html; }, 10, 2);
