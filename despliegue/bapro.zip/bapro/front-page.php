<?php get_header(); ?>
<?php bapro_seccion_intro(); bapro_seccion_datos(); bapro_seccion_historias(); bapro_seccion_programas(); bapro_seccion_alianzas('convenios'); bapro_seccion_novedades(); bapro_seccion_territorio(); ?>
<?php get_footer(); ?>
