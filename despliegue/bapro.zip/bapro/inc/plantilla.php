<?php
/** Secciones de la portada y piezas compartidas. Cada función imprime el mismo HTML del boceto aprobado, con los datos cargados en el panel. */
if (!defined('ABSPATH')) exit;
function bapro_u($path) { return esc_url(home_url($path)); }
/** Enlaces del menú (los mismos para escritorio y celular). */
function bapro_menu_links() {
    $items = [[home_url('/'), 'Inicio', is_front_page()], [home_url('/la-fundacion/'), 'La Fundación', is_page('la-fundacion')], [home_url('/#programas'), 'Lo que hacemos', is_singular('programa') && !is_page('formacion')]];
    foreach ($items as [$u, $t, $on]) echo '<a' . ($on ? ' class="on"' : '') . ' href="' . esc_url($u) . '">' . esc_html($t) . '</a>';
    echo '<a' . (is_page('formacion') ? ' class="on"' : '') . ' href="' . bapro_u('/formacion/') . '">AURA</a>';  // 28/10: en el menú queda sólo AURA
    echo '<a' . ((is_home() || is_singular('post')) ? ' class="on"' : '') . ' href="' . bapro_u('/novedades/') . '">Novedades</a>';
}
function bapro_social() {
    $ig = bapro_opt('instagram');  // 28/10: la Fundación pidió sacar el botón de WhatsApp
    echo '<div class="social">';
    if ($ig) echo '<a class="social__ig" href="' . esc_url($ig) . '" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="#fff" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="#fff" stroke="none"/></svg></a>';
    echo '</div>';
}
function bapro_img($id, $tam = 'ancha', $alt = '', $extra = '') {
    if (!$id) return '';
    if (is_numeric($id)) return wp_get_attachment_image((int)$id, $tam, false, ['alt' => $alt] + ($extra ? ['class' => $extra] : []));
    return '<img src="' . esc_url($id) . '" alt="' . esc_attr($alt) . '"' . ($extra ? ' class="' . esc_attr($extra) . '"' : '') . ' loading="lazy">';
}
/* ---------- Portada ---------- */
function bapro_seccion_intro() {
    $html = file_get_contents(BAPRO_T . '/parts/intro.html'); $A = BAPRO_TU . '/assets';
    $vh = bapro_opt('video_h') ?: $A . '/video/intro-h.mp4'; $vv = bapro_opt('video_v') ?: $A . '/video/intro-v.mp4'; $po = bapro_opt('poster') ?: $A . '/video/poster-h.jpg';
    $frase = bapro_opt('frase'); $partes = preg_split('/\s+(?=que\b)/u', $frase, 2); if (count($partes) < 2) $partes = [$frase, ''];
    $fr = '<span class="intro__line" data-line="1">' . esc_html(trim($partes[0])) . '</span>' . ($partes[1] ? '<br><span class="intro__line" data-line="2">' . esc_html(trim($partes[1])) . '</span>' : '<span class="intro__line" data-line="2" style="display:none"></span>');
    $tx = '';  // 28/10: no va texto debajo de la frase
    $cta = '<div class="cta"><a class="btn ghost" href="' . esc_url(bapro_opt('video_completo')) . '" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>Ver el video completo</a></div>';  // 28/10: sin botón de distrito
    echo str_replace(['{{POSTER}}', '{{VIDEO_V}}', '{{VIDEO_H}}', '{{LOGO}}', '{{FRASE}}', '{{TEXTO}}', '{{CTA}}'], [esc_url($po), esc_url($vv), esc_url($vh), $A . '/logo.svg', $fr, $tx, $cta], $html);
}
function bapro_numeros() {
    if (bapro_opt('numeros_origen') === 'planilla' && function_exists('bapro_totales')) {
        $t = bapro_totales(); $u = $t['unidades']; $out = [];
        foreach ([['anteojos', 'anteojos entregados'], ['clubes', 'clubes acompañados'], ['plazas', 'plazas hechas'], ['instrumentos', 'instrumentos entregados']] as [$k, $l]) if (!empty($u[$k])) $out[] = [$u[$k], $l];
        if (count($out) >= 2) return $out;
    }
    $out = []; for ($i = 1; $i <= 4; $i++) { $v = preg_replace('/\D/', '', bapro_opt("num{$i}_valor")); if ($v !== '') $out[] = [(int)$v, bapro_opt("num{$i}_texto")]; }
    return $out;
}
function bapro_seccion_datos() {
    echo '<section class="sec" id="datos"><div class="wrap"><div class="head" style="text-align:center;margin-bottom:0"><h2 class="title">Lo que ya pasó en la provincia</h2></div><div class="big">';
    foreach (bapro_numeros() as [$v, $l]) echo '<div data-count="' . (int)$v . '"><b>0</b><span>' . esc_html($l) . '</span></div>';
    echo '</div></div></section>';
}
function bapro_seccion_historias() {
    $hs = get_posts(['post_type' => 'historia', 'numberposts' => 4, 'orderby' => 'menu_order', 'order' => 'ASC']); if (!$hs) return;
    echo '<section class="sec sec--alt" data-v="historias:cards" id="historias" style="padding-bottom:0"><div class="wrap"><div class="head"><div class="eyebrow">Lo que estamos haciendo</div><h2 class="title">' . esc_html(bapro_opt('historias_titulo')) . '</h2></div></div>';
    $pasos_max = 1; $cards = '';
    foreach ($hs as $h) {
        $id = $h->ID; $enlace = bapro_meta($id, 'enlace', '#'); $et = bapro_meta($id, 'etiqueta', $h->post_title); $pasos = [];
        for ($i = 1; $i <= 3; $i++) if (bapro_meta($id, "paso{$i}_t")) $pasos[] = [bapro_meta($id, "paso{$i}_t"), bapro_meta($id, "paso{$i}_p"), bapro_meta($id, "paso{$i}_img")];
        if (!$pasos) $pasos = [[$h->post_title, '', '']]; $pasos_max = max($pasos_max, count($pasos));
        $foco = bapro_meta($id, 'foco', '50% 50%'); $imgs = '';
        foreach ($pasos as $k => $p) { $aid = $p[2] && is_numeric($p[2]) ? (int)$p[2] : get_post_thumbnail_id($id); $attrs = ['class' => $k === 0 ? 'on' : '', 'alt' => '', 'data-cs-ph' => '', 'style' => 'object-position:' . esc_attr($foco), 'sizes' => '(max-width: 900px) 100vw, 1280px'];
            $imgs .= $aid ? wp_get_attachment_image($aid, 'full', false, $attrs) : '<img' . ($k === 0 ? ' class="on"' : '') . ' src="' . esc_url($p[2]) . '" alt="" data-cs-ph style="object-position:' . esc_attr($foco) . '">'; }
        $steps = ''; foreach ($pasos as $k => $p) $steps .= '<div class="cs__step' . ($k === 0 ? ' on' : '') . '"><h3>' . esc_html($p[0]) . '</h3><p>' . ($p[1] ? esc_html($p[1]) : bapro_falta('texto corto del paso ' . ($k + 1) . ' de ' . $et)) . '</p></div>';
        $dots = str_repeat('<i></i>', count($pasos)); $dots = '<i class="on"></i>' . substr($dots, 7);
        $cards .= '<div class="cs__card" data-cst-card data-n="' . count($pasos) . '">' . $imgs . '<div class="cs__shade"></div><a class="cs__link" href="' . esc_url($enlace) . '" aria-label="' . esc_attr($et) . '"></a><div class="cs__ttl">' . esc_html($et) . (bapro_meta($id, 'subtitulo') ? '<small>' . esc_html(bapro_meta($id, 'subtitulo')) . '</small>' : '') . '</div><div class="cs__txt">' . $steps . '<a class="btn grad" href="' . esc_url($enlace) . '">' . esc_html(bapro_meta($id, 'boton', 'Leer más')) . '</a></div><div class="cs__dots">' . $dots . '</div></div>';
    }
    echo '<div class="cst" data-cst style="--n:' . $pasos_max . ';--m:' . count($hs) . '"><div class="cst__vp"><div class="wrap"><div class="cst__track">' . $cards . '</div></div></div></div></section>';
}
function bapro_seccion_programas() {
    $ps = array_values(array_filter(get_posts(['post_type' => 'programa', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC']), function ($p) { return bapro_meta($p->ID, 'en_portada', 'si') !== 'no'; })); if (!$ps) return;
    echo '<section class="sec pbg pbg--2" data-v="programas:tarjetas" id="programas"><div class="wrap"><div class="head"><div class="eyebrow">Lo que hacemos</div><h2 class="title">' . esc_html(bapro_opt('programas_titulo')) . '</h2><p class="lead">Al pasar el cursor, cada tarjeta se da vuelta y muestra el programa. Tocala para entrar.</p></div><div class="pv-grid">';
    foreach ($ps as $p) {
        $id = $p->ID; $c = bapro_meta($id, 'color', 'verde'); $img = get_the_post_thumbnail_url($id, 'tarjeta'); $dorso = bapro_meta($id, 'foto_dorso'); $img2 = ($dorso && is_numeric($dorso)) ? (wp_get_attachment_image_url((int)$dorso, 'tarjeta') ?: $img) : $img;
        echo '<a class="pv" href="' . esc_url(get_permalink($id)) . '" style="--c:var(--' . esc_attr($c) . ')"><div class="pv__in"><div class="pv__face pv__front"><img src="' . esc_url($img) . '" alt=""><p class="pv__why">' . esc_html(bapro_meta($id, 'frase', $p->post_title)) . '</p></div><div class="pv__face pv__back"><img src="' . esc_url($img2) . '" alt=""><div class="pv__bt"><h3>' . esc_html($p->post_title) . '</h3><p class="pv__desc">' . esc_html(bapro_meta($id, 'bajada')) . '</p><span class="pv__btn">Ver más <i>→</i></span></div></div></div></a>';
    }
    echo '</div></div></section>';
}
function bapro_seccion_alianzas($id_sec = 'convenios') {
    $as = get_posts(['post_type' => 'alianza', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC']); $banner = array_values(array_filter($as, function ($a) { return bapro_meta($a->ID, 'en_banner', 'si') === 'si'; }));
    $zoc = array_filter(array_map('trim', explode("\n", bapro_opt('alianzas_zocalo'))));
    echo '<section class="sec sec--alt pbg pbg--2" id="' . esc_attr($id_sec) . '"><div class="wrap"><div class="head head--row"><div><div class="eyebrow">Nuestras alianzas</div><h2 class="title">' . esc_html(bapro_opt('alianzas_titulo')) . '</h2><p class="lead">' . esc_html(bapro_opt('alianzas_bajada')) . '</p></div><div class="cv__nav"><button type="button" data-cv="-1" aria-label="Anterior">‹</button><button type="button" data-cv="1" aria-label="Siguiente">›</button></div></div></div>';
    // 28/10: la Fundación pidió un carrusel más chico: tarjetas en fila, en vez del banner a pantalla completa
    if ($as) {
        echo '<div class="wrap"><div class="cv" data-v="convenios:tarjetas"><div class="cv__track" data-cv-track>';
        foreach ($as as $a) { $img = get_the_post_thumbnail_url($a->ID, 'ancha'); $logo = bapro_meta($a->ID, 'logo'); $logo_html = ($logo && is_numeric($logo)) ? wp_get_attachment_image((int)$logo, 'thumbnail', false, ['alt' => $a->post_title, 'style' => 'height:34px;width:auto']) : '<span>Logo</span>'; $fr = bapro_meta($a->ID, 'frase'); $tx = bapro_meta($a->ID, 'texto');
            echo '<article class="cv__it"><div class="cv__ph">' . ($img ? '<img src="' . esc_url($img) . '" alt="">' : '<div class="cv__nofoto">' . (is_user_logged_in() ? 'Falta la foto: la manda la Fundación' : '') . '</div>') . '<div class="cv__logo">' . $logo_html . esc_html($a->post_title) . '</div></div><div class="cv__t"><h3>' . ($fr ? esc_html($fr) : bapro_falta('la frase de la alianza ' . $a->post_title)) . '</h3><p class="cv__con">' . ($tx ? esc_html($tx) : bapro_falta('el texto de la alianza ' . $a->post_title)) . '</p>' . bapro_alianza_mas($a->ID, 'cv') . '</div></article>'; }
        echo '</div></div></div>';
    }
    if ($banner) {
        echo '<div class="al" data-v="convenios:banner" data-al>';
        foreach ($banner as $k => $a) { $fotos = bapro_alianza_fotos($a->ID);
            echo '<div class="al__slide' . ($k === 0 ? ' on' : '') . '" data-al-slide>';
            if ($fotos) { foreach ($fotos as $j => $f) echo '<img class="al__ph' . ($j === 0 ? ' on' : '') . '" src="' . esc_url($f) . '" alt="" data-al-ph' . ($j > 0 ? ' loading="lazy"' : '') . '>'; } else echo '<div class="cv__nofoto">' . (is_user_logged_in() ? 'Falta la foto: la manda la Fundación' : '') . '</div>';
            echo '<div class="al__shade"></div><div class="al__txt"><div class="eyebrow"><span data-alt-d>Alianzas</span><span data-alt-a>' . esc_html($a->post_title) . '</span></div><div class="al__who" data-alt-d>' . esc_html($a->post_title) . '</div><h3>' . esc_html(bapro_meta($a->ID, 'frase')) . '</h3><p class="al__con">' . (bapro_meta($a->ID, 'texto') ? esc_html(bapro_meta($a->ID, 'texto')) : bapro_falta('texto de la alianza ' . $a->post_title)) . '</p>' . bapro_alianza_mas($a->ID, 'al') . '</div></div>'; }
        echo '<div class="al__dots" data-al-dots>'; foreach ($banner as $k => $a) echo '<i' . ($k === 0 ? ' class="on"' : '') . '></i>'; echo '</div>';
        echo '<button class="al__arr al__arr--l" type="button" data-al-go="-1" aria-label="Anterior"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg></button><button class="al__arr al__arr--r" type="button" data-al-go="1" aria-label="Siguiente"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg></button></div>';
    }
    if ($zoc) { echo '<div class="wrap"><div class="sx-marq" data-v="banda:si" aria-hidden="true"><div class="sx-marq__track">'; for ($r = 0; $r < 2; $r++) foreach ($zoc as $z) echo '<span>' . esc_html($z) . '</span>'; echo '</div></div></div>'; }
    echo '</section>';
}
/** Enlace "Ver más sobre esta alianza": a la página de la alianza (03/11), o al enlace que carguen en el panel. */
function bapro_alianza_mas($id, $pref) { $en = bapro_meta($id, 'enlace') ?: get_permalink($id); return '<a class="sx-link" href="' . esc_url($en) . '">Ver más sobre esta alianza →</a>'; }
/** Fotos de una alianza: la destacada y las extra del campo galería (direcciones, tamaño ancho). */
function bapro_alianza_fotos($id, $tam = 'ancha') { $out = []; if (has_post_thumbnail($id)) $out[] = get_the_post_thumbnail_url($id, $tam); foreach (array_filter(array_map('trim', explode(',', bapro_meta($id, 'galeria')))) as $g) if (is_numeric($g) && ($u = wp_get_attachment_image_url((int)$g, $tam))) $out[] = $u; return array_values(array_unique($out)); }
/** Novedades de una alianza: las que nombran alguna de sus palabras clave. */
function bapro_alianza_novedades($id, $n = 3) { global $wpdb; $claves = array_filter(array_map('trim', explode(',', bapro_meta($id, 'claves')))); if (!$claves) return []; $w = []; foreach ($claves as $k) { $l = '%' . $wpdb->esc_like($k) . '%'; $w[] = $wpdb->prepare('(post_title LIKE %s OR post_content LIKE %s)', $l, $l); } $ids = $wpdb->get_col("SELECT ID FROM $wpdb->posts WHERE post_type='post' AND post_status='publish' AND (" . implode(' OR ', $w) . ") ORDER BY post_date DESC LIMIT " . (int)$n); return $ids ? get_posts(['post__in' => $ids, 'orderby' => 'post__in', 'numberposts' => $n]) : []; }
function bapro_fecha_corta($post) { $m = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic']; return get_the_date('j', $post) . ' ' . $m[(int)get_the_date('n', $post) - 1]; }
function bapro_programa_de($post) { $t = wp_get_post_terms($post->ID, 'programa_tax'); if ($t) return $t[0]->name; $c = get_the_category($post->ID); return $c ? $c[0]->name : 'Novedades'; }
function bapro_seccion_novedades() {
    $ps = get_posts(['numberposts' => 5]); if (!$ps) return; $m = array_shift($ps);
    echo '<section class="sec pbg pbg--2" data-v="novedades:lista" id="novedades"><div class="wrap"><div class="head head--row"><div><div class="eyebrow">Novedades</div><h2 class="title">Novedades.</h2></div><a class="btn ghost" href="' . bapro_u('/novedades/') . '">Todas las novedades</a></div></div>';
    $yt = function_exists('bapro_video_destacado') ? bapro_video_destacado() : null; $yt_html = '';
    if ($yt) $yt_html = '<div class="wrap"><div class="yt yt--compacto" style="margin:34px 0 0"><div class="yt__v"><iframe src="https://www.youtube-nocookie.com/embed/' . esc_attr($yt['id']) . '?rel=0" title="' . esc_attr($yt['titulo'] ?: 'Video de la Fundación') . '" loading="lazy" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div><div class="yt__t"><div class="eyebrow">Video</div>' . ($yt['titulo'] ? '<h3>' . esc_html($yt['titulo']) . '</h3>' : '') . '<p>' . (bapro_yt_id(bapro_opt('video_destacado')) ? 'El video que la Fundación quiere mostrar.' : 'El último video del canal de la Fundación.') . '</p><a class="btn ghost" href="https://www.youtube.com/channel/' . esc_attr(bapro_opt('youtube_canal')) . '" target="_blank" rel="noopener">Ver todos los videos en YouTube</a></div></div></div>';
    echo '<div class="wrap"><div class="news-grid">';
    echo '<a class="news-main" href="' . esc_url(get_permalink($m)) . '"><img src="' . esc_url(bapro_foto($m->ID)) . '" alt=""><div class="txt"><div class="eyebrow">' . esc_html(bapro_programa_de($m) . ' · ' . bapro_fecha_corta($m)) . '</div><h3>' . esc_html(get_the_title($m)) . '</h3></div></a><div class="news-list">';
    foreach ($ps as $p) echo '<a class="news-item" href="' . esc_url(get_permalink($p)) . '"><img src="' . esc_url(bapro_foto($p->ID, 'cuadrada')) . '" alt=""><div><div class="d">' . esc_html(bapro_programa_de($p) . ' · ' . bapro_fecha_corta($p)) . '</div><h4>' . esc_html(get_the_title($p)) . '</h4></div></a>';
    echo '</div></div></div>' . $yt_html . '</section>';  // 02/11: el video va después de las novedades, como pide el documento de la Fundación
}
function bapro_seccion_territorio() { if (bapro_opt('mapa') !== 'si') return; $h = file_get_contents(BAPRO_T . '/parts/territorio.html'); echo $h; }
/* ---------- Piezas de páginas interiores ---------- */
function bapro_nc($p) { return '<a class="nc" href="' . esc_url(get_permalink($p)) . '"><div class="ph"><img src="' . esc_url(bapro_foto($p->ID, 'tarjeta')) . '" alt="" loading="lazy"></div><div class="b"><div class="lbl">' . esc_html(bapro_programa_de($p) . ' · ' . get_the_date('j \d\e F', $p)) . '</div><h3>' . esc_html(get_the_title($p)) . '</h3></div></a>'; }
function bapro_relacionadas($programa_id, $n = 6) { $slug = get_post_field('post_name', $programa_id); $t = get_term_by('slug', $slug, 'programa_tax'); if (!$t) return []; return get_posts(['numberposts' => $n, 'tax_query' => [['taxonomy' => 'programa_tax', 'field' => 'term_id', 'terms' => $t->term_id]]]); }
