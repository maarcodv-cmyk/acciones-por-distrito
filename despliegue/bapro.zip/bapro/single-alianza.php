<?php /* Página de una alianza (03/11): cabecera con la foto, frase, texto largo, galería y novedades que la nombran. */ get_header(); the_post(); $id = get_the_ID();
$fotos = bapro_alianza_fotos($id); $rel = bapro_alianza_novedades($id, 12); $gal = $fotos;
foreach ($rel as $q) { if (count($gal) >= 9) break; $f = bapro_foto($q->ID, 'ancha'); if ($f && !in_array($f, $gal, true)) $gal[] = $f; } $gal = array_slice($gal, 0, 9); ?>
<article>
<section class="phero phero--img"><?php if ($fotos) echo '<img class="phero__bg" src="' . esc_url($fotos[0]) . '" alt="">'; ?><div class="wrap"><div class="crumb"><a href="<?php echo bapro_u('/#convenios'); ?>">Nuestras alianzas</a> · <?php the_title(); ?></div><h1><?php echo esc_html(bapro_meta($id, 'frase') ?: get_the_title()); ?></h1><p class="lead"><?php echo esc_html(bapro_meta($id, 'texto')); ?></p></div></section>
<section class="sec pbg"><div class="wrap"><div class="two"><div class="prose"><?php $m = bapro_meta($id, 'mas'); echo $m ? wpautop(esc_html($m)) : '<p>' . bapro_falta('el texto largo de la alianza ' . get_the_title()) . '</p>'; ?></div></div></div></section>
<?php if (count($gal) >= 3) : ?><section class="sec pbg pbg--left" style="padding-top:0"><div class="wrap"><div class="gal gal--3"><?php foreach ($gal as $g) echo '<div><img src="' . esc_url($g) . '" alt="" loading="lazy"></div>'; ?></div></div></section><?php endif; ?>
<?php if ($rel) : ?><section class="sec pbg"><div class="wrap"><div class="head head--row"><div><div class="eyebrow">Novedades</div><h2 class="title">Lo último con <?php the_title(); ?>.</h2></div><a class="btn ghost" href="<?php echo bapro_u('/novedades/'); ?>">Todas las novedades</a></div><div class="ngrid"><?php foreach (array_slice($rel, 0, 3) as $q) echo bapro_nc($q); ?></div></div></section><?php endif; ?>
</article>
<?php get_footer(); ?>
