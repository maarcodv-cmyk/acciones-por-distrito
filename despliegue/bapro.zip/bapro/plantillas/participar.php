<?php /* Template Name: Participar */ get_header(); the_post(); ?>
<section class="phero pbg"><div class="wrap"><div class="eyebrow">Participar</div><h1 style="margin-top:14px">Una conversación puede ser el comienzo.</h1><p class="lead">Si tu club, escuela, hospital o municipio quiere participar de un programa, dejanos los datos. La solicitud llega al equipo de la Fundación y queda registrada.</p><?php if (!empty($_GET['enviado'])) echo '<div class="aviso-ok">Gracias. Recibimos la solicitud y te mandamos un correo de confirmación.</div>'; ?></div></section>
<section class="sec pbg" style="padding-top:0"><div class="wrap"><?php echo function_exists('bapro_form_html') ? bapro_form_html('participar') : ''; ?></div></section>
<?php get_footer(); ?>
