<?php /* Template Name: Contacto */ get_header(); the_post(); ?>
<section class="phero pbg"><div class="wrap"><div class="eyebrow">Contacto</div><h1 style="margin-top:14px">Escribinos.</h1><p class="lead"><?php echo esc_html(bapro_opt('direccion')); ?> · <?php echo esc_html(bapro_opt('telefono')); ?></p><?php if (!empty($_GET['enviado'])) echo '<div class="aviso-ok">Gracias. Recibimos tu mensaje y te mandamos un correo de confirmación.</div>'; ?></div></section>
<section class="sec pbg" style="padding-top:0"><div class="wrap"><?php echo function_exists('bapro_form_html') ? bapro_form_html('contacto') : ''; ?></div></section>
<?php get_footer(); ?>
