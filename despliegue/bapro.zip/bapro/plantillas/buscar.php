<?php /* Template Name: Buscar */ get_header(); the_post(); ?>
<section class="phero pbg"><div class="wrap"><div class="eyebrow">Buscar</div><h1 style="margin-top:14px">¿Qué estás buscando?</h1><div style="max-width:720px"><?php get_search_form(); ?></div></div></section>
<?php get_footer(); ?>
