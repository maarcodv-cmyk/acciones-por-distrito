<?php /* Template Name: Territorio (mapa) */ get_header(); the_post(); ?>
<?php if (bapro_opt('mapa') === 'si') { echo file_get_contents(BAPRO_T . '/parts/territorio.html'); } else { ?><section class="phero pbg"><div class="wrap"><div class="eyebrow">Territorio</div><h1 style="margin-top:14px">El mapa está apagado.</h1><p class="lead">Se prende desde el panel, en Portada y sitio.</p></div></section><?php } ?>
<?php get_footer(); ?>
