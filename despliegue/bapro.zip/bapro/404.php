<?php get_header(); ?>
<section class="phero pbg"><div class="wrap"><div class="eyebrow">Error 404</div><h1 style="margin-top:14px">Esa página no existe.</h1><p class="lead">Puede que el enlace sea viejo. Probá desde el inicio o buscá lo que necesitás.</p><a class="btn grad" href="<?php echo esc_url(home_url('/')); ?>">Ir al inicio</a></div></section>
<section class="sec pbg" style="padding-top:0"><div class="wrap" style="max-width:720px"><?php get_search_form(); ?></div></section>
<?php get_footer(); ?>
