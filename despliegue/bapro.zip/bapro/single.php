<?php get_header(); the_post(); $p = get_post(); $url = get_permalink(); $txt = mb_strtolower(get_the_title() . ' ' . get_the_content());
$insc = (strpos($txt, 'aura') !== false || strpos($txt, 'inscrib') !== false || strpos($txt, 'inscripci') !== false) ? '<a class="btn grad" href="' . bapro_u('/formacion/') . '" style="margin-top:22px">Inscribirse</a>' : '';
$rel = get_posts(['numberposts' => 4, 'exclude' => [$p->ID]]); ?>
<article>
<section class="phero pbg" style="padding-bottom:30px"><div class="wrap"><div class="crumb"><a href="<?php echo bapro_u('/novedades/'); ?>">Novedades</a> · <?php echo esc_html(bapro_programa_de($p)); ?> · <?php echo esc_html(get_the_date('j \d\e F \d\e Y')); ?></div><h1><?php the_title(); ?></h1><?php echo $insc; ?></div></section>
<section class="sec pbg" style="padding-top:0"><div class="wrap"><div class="two"><div class="prose"><?php if (has_post_thumbnail()) the_post_thumbnail('ancha'); the_content(); ?>
<div class="share"><a href="https://wa.me/?text=<?php echo rawurlencode(get_the_title() . ' ' . $url); ?>" target="_blank" rel="noopener">Compartir por WhatsApp</a><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo rawurlencode($url); ?>" target="_blank" rel="noopener">Compartir en Facebook</a><a href="https://twitter.com/intent/tweet?url=<?php echo rawurlencode($url); ?>&text=<?php echo rawurlencode(get_the_title()); ?>" target="_blank" rel="noopener">Compartir en X</a></div></div>
<aside class="aside"><div class="eyebrow">Más novedades</div><div style="display:grid;gap:14px;margin-top:16px"><?php foreach ($rel as $q) echo '<a class="news-item" href="' . esc_url(get_permalink($q)) . '"><img src="' . esc_url(bapro_foto($q->ID, 'cuadrada')) . '" alt=""><div><div class="d">' . esc_html(bapro_programa_de($q)) . '</div><h4>' . esc_html(get_the_title($q)) . '</h4></div></a>'; ?></div></aside></div></div></section>
</article>
<?php get_footer(); ?>
