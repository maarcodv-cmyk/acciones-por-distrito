</main>
<footer><div class="wrap">
 <div><img src="<?php echo BAPRO_TU; ?>/assets/logo.svg" alt="" style="height:40px;filter:brightness(0) invert(1);margin-bottom:16px"><div><?php echo esc_html(bapro_opt('direccion')); ?><br><?php echo esc_html(bapro_opt('mail_formularios')); ?> · <?php echo esc_html(bapro_opt('telefono')); ?></div></div>
 <div><b>Programas</b><?php foreach (get_posts(['post_type' => 'programa', 'numberposts' => 5, 'orderby' => 'menu_order', 'order' => 'ASC']) as $p) echo '<a href="' . esc_url(get_permalink($p)) . '">' . esc_html($p->post_title) . '</a><br>'; ?><a href="<?php echo esc_url(home_url('/#programas')); ?>">Lo que hacemos</a></div>
 <div><b>La Fundación</b><a href="<?php echo esc_url(home_url('/la-fundacion/')); ?>">Quiénes somos</a><br><a href="<?php echo esc_url(home_url('/la-fundacion/#autoridades')); ?>">Autoridades</a><br><a href="<?php echo esc_url(home_url('/#convenios')); ?>">Alianzas</a></div>
 <div><b>Seguinos</b><?php if (bapro_opt('instagram')) : ?><a href="<?php echo esc_url(bapro_opt('instagram')); ?>" target="_blank" rel="noopener">Instagram</a><br><?php endif; ?><a href="https://www.youtube.com/channel/<?php echo esc_attr(bapro_opt('youtube_canal')); ?>" target="_blank" rel="noopener">YouTube</a><?php if (bapro_opt('facebook')) : ?><br><a href="<?php echo esc_url(bapro_opt('facebook')); ?>" target="_blank" rel="noopener">Facebook</a><?php endif; ?></div>
 <div class="bot"><span>© <?php echo date('Y'); ?> Fundación Banco Provincia</span><span><a href="<?php echo esc_url(home_url('/privacidad/')); ?>">Privacidad</a> · <a href="<?php echo esc_url(home_url('/accesibilidad/')); ?>">Accesibilidad</a></span></div>
</div></footer>
<?php bapro_social(); ?>
<script>window.BAPRO={inicio:<?php echo json_encode(home_url('/')); ?>,mapa:<?php echo (bapro_opt('mapa') === 'si' && function_exists('bapro_mapa_datos')) ? wp_json_encode((object)bapro_mapa_datos(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '{}'; ?>};</script>
<?php wp_footer(); ?>
</body>
</html>
