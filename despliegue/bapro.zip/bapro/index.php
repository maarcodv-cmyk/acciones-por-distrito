<?php get_header(); ?>
<section class="phero pbg"><div class="wrap"><h1><?php echo esc_html(get_the_archive_title()); ?></h1></div></section>
<section class="sec pbg" style="padding-top:0"><div class="wrap"><div class="ngrid"><?php while (have_posts()) { the_post(); echo bapro_nc(get_post()); } ?></div><?php the_posts_pagination(['prev_text' => '← Anteriores', 'next_text' => 'Siguientes →']); ?></div></section>
<?php get_footer(); ?>
