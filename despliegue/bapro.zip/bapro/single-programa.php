<?php get_header(); the_post(); $id = get_the_ID(); $area = wp_get_post_terms($id, 'area'); $cat = $area ? $area[0]->name : '';
$cont = apply_filters('the_content', get_the_content()); $lead = bapro_meta($id, 'lead'); if (!$lead && preg_match('~<p>(.*?)</p>~s', $cont, $m)) { $lead = wp_strip_all_tags($m[1]); $cont = preg_replace('~<p>.*?</p>~s', '', $cont, 1); }
$testim = array_filter(array_map('trim', explode("\n", bapro_meta($id, 'testimonios')))); $part = bapro_meta($id, 'participar');
$tot = function_exists('bapro_totales') ? bapro_totales() : ['programas' => []]; $nombres = array_filter(array_map('trim', explode("\n", bapro_meta($id, 'planilla_nombres', get_the_title())))); $dists = []; $unid = [];
foreach ($nombres as $n) if (!empty($tot['programas'][$n])) { $dists += $tot['programas'][$n]['distritos']; foreach ($tot['programas'][$n]['unidades'] as $u => $v) $unid[$u] = ($unid[$u] ?? 0) + $v; }
arsort($unid); $unid = array_slice($unid, 0, 2, true);
$gal = array_filter(array_map('trim', explode(',', bapro_meta($id, 'galeria')))); $rel = bapro_relacionadas($id, 12);
if (!$gal) { foreach ($rel as $q) { $f = bapro_foto($q->ID, 'ancha'); if ($f) $gal[] = $f; if (count($gal) >= 9) break; } } $gal = array_slice($gal, 0, 9); $gal_titulo = bapro_meta($id, 'galeria_titulo'); $mostrar_numeros = bapro_opt('numeros_programas') === 'si' && bapro_meta($id, 'numeros', 'si') !== 'no' && $dists; ?>
<article>
<?php $portada = bapro_meta($id, 'portada'); $hero = ($portada && is_numeric($portada)) ? wp_get_attachment_image_url((int)$portada, 'ancha') : ''; if (!$hero && has_post_thumbnail()) $hero = get_the_post_thumbnail_url($id, 'ancha'); ?>
<section class="phero phero--img"><?php if ($hero) echo '<img class="phero__bg" src="' . esc_url($hero) . '" alt="">'; ?><div class="wrap"><div class="crumb"><a href="<?php echo bapro_u('/#programas'); ?>">Lo que hacemos</a> · <?php echo esc_html($cat); ?></div><h1><?php the_title(); ?></h1><p class="lead"><?php echo esc_html($lead); ?></p></div></section>
<section class="sec pbg"><div class="wrap"><div class="two"><div class="prose"><?php echo $cont; ?>
</div><?php /* 28/10: la Fundación decidió que no va el bloque "Cómo participar" en los programas */ ?>
<?php if ($mostrar_numeros) : ?><aside class="aside"><div class="eyebrow">Lo que ya pasó</div><h2 class="title" style="font-size:28px;margin-bottom:22px">En números.</h2>
<?php if ($dists) : ?><div class="stat"><div><b><?php echo count($dists); ?></b><span>distritos con acciones de este programa</span></div><?php foreach ($unid as $u => $v) echo '<div><b>' . esc_html(bapro_num($v)) . '</b><span>' . esc_html($u) . '</span></div>'; ?></div><p style="font-size:13px;color:var(--i3);margin-top:18px">Los números salen de la planilla de acciones por distrito.</p><?php else : ?><p style="color:var(--i3);font-size:14px">Los números de este programa se cargan desde la planilla de acciones por distrito.</p><?php endif; ?>
<?php if (bapro_opt('mapa') === 'si') : ?><a class="sx-link" href="<?php echo bapro_u('/territorio/'); ?>">Ver el mapa de acciones →</a><?php endif; ?></aside><?php endif; ?></div>
<?php if ($testim) : ?><div class="quotes"><?php foreach ($testim as $t) { $pp = array_map('trim', explode('|', $t)); echo '<div class="quote">' . esc_html($pp[0]) . '<small>' . esc_html($pp[1] ?? '') . '</small></div>'; } ?></div><?php endif; ?>
</div></section>
<?php if (count($gal) >= 3) : ?><section class="sec pbg pbg--left" style="padding-top:0"><div class="wrap"><?php if ($gal_titulo) echo '<div class="head"><h2 class="title">' . esc_html($gal_titulo) . '</h2></div>'; ?><div class="gal gal--3"><?php foreach ($gal as $g) { $src = is_numeric($g) ? wp_get_attachment_image_url((int)$g, 'ancha') : $g; echo '<div><img src="' . esc_url($src) . '" alt="" loading="lazy"></div>'; } ?></div></div></section><?php endif; ?>
<?php if ($rel) : ?><section class="sec pbg"><div class="wrap"><div class="head head--row"><div><div class="eyebrow">Novedades</div><h2 class="title">Lo último de <?php the_title(); ?>.</h2></div><a class="btn ghost" href="<?php echo bapro_u('/novedades/'); ?>">Todas las novedades</a></div><div class="ngrid"><?php foreach (array_slice($rel, 0, 3) as $q) echo bapro_nc($q); ?></div></div></section><?php endif; ?>
</article>
<?php get_footer(); ?>
