const D=(window.BAPRO&&window.BAPRO.mapa)||{};
;

(function(){
 // --- variantes: se quitan del documento las que no se eligieron
 var h=document.documentElement;
 var GO={menu:{formacion:'#inicio',separado:'#inicio'},turquesa:{programas:'#programas',novedades:'#novedades',alianzas:'#convenios'},altitulo:{dentro:'#convenios',arriba:'#convenios'},letras:{sombra:'#historias',relieve:'#historias',oscurecer:'#historias'},linea:{si:'#linea',no:'#novedades'},fondo:{liso:'#programas',silueta:'#programas',contorno:'#territorio',bloques:'#convenios'},mapa:{si:'#territorio',no:'#novedades'},respira:{si:'#historias',no:'#historias'},boton:{si:'#datos',no:'#datos'},banda:{si:'#convenios',no:'#convenios'},buscando:{si:'#datos',no:'#datos'},datos:{foto:'#datos',liso:'#datos'},historias:{foto:'#historias',scroll:'#historias-scroll',scrollfoto:'#historias-scrollfoto',scrollfoto2:'#historias-scrollfoto2',tarjetas:'#historias-tarjetas'},convenios:{banner:'#convenios',tarjetas:'#convenios',entera:'#convenios',marquee:'#convenios'},programas:{tarjetas:'#programas',fichas:'#programas-fichas'},novedades:{lista:'#novedades',tarjetas:'#novedades-tarjetas',grilla:'#novedades-grilla'}};
 window.addEventListener('pageshow',function(){ setTimeout(videosOn,100); setTimeout(videosOn,800); }); window.addEventListener('load',function(){ setTimeout(videosOn,300); });
function videosOn(){ document.querySelectorAll('video').forEach(function(v){ var vis=!!(v.offsetWidth||v.offsetHeight||v.getClientRects().length); if(vis){ if(v.autoplay&&v.paused) v.play().catch(function(){}); } else if(!v.paused) v.pause(); }); }
 function setV(k,val,scroll){ h.setAttribute('data-'+k,val); if(window.__rebands) window.__rebands(); try{ sessionStorage.setItem('h1c-opt-'+k,val); }catch(e){} try{ var p=new URLSearchParams(location.search); p.set(k,val); history.replaceState(null,'',location.pathname+'?'+p.toString()+location.hash); }catch(e){}
   document.querySelectorAll('.vbar__b[data-k="'+k+'"] button').forEach(function(b){ b.classList.toggle('on',b.dataset.val===val); });
   if(k==='portada'){ var ld=document.getElementById('loader'); if(ld){ if(val==='banner'){ ld.classList.remove('off'); setTimeout(function(){ld.classList.add('off')},2100); } } if(scroll) window.scrollTo({top:0,behavior:'auto'}); }
   else if(scroll && GO[k]){ var el=document.querySelector((k==='fondo'&&val!=='contorno'&&h.getAttribute('data-programas')==='fichas')?'#programas-fichas':GO[k][val]); if(el){ var y=el.getBoundingClientRect().top+window.scrollY-20; window.scrollTo({top:y,behavior:'auto'}); } }
   if(k==='mapa' && val==='si' && window.__lightMap) setTimeout(window.__lightMap,400); if((k==='boton'||k==='buscando') && scroll){ var q=document.querySelector('.quick'); window.scrollTo({top:(k==='buscando'&&q)?q.getBoundingClientRect().top+window.scrollY-300:0,behavior:'auto'}); } videosOn(); window.dispatchEvent(new Event('scroll')); }
 ['portada','tono','fondo','datos','historias','programas','novedades','mapa','linea','respira','boton','banda','buscando','convenios','letras'].forEach(function(k){ setV(k,h.getAttribute('data-'+k),false); });
 var bar=document.getElementById('vbar'), pill=document.getElementById('vpill');
 var th=document.getElementById('theme'); if(th){ th.addEventListener('click',function(){ var c=h.getAttribute('data-tono')!=='oscuro'; setV('tono',c?'oscuro':'blanco',false); th.querySelector('span').textContent=c?'Modo noche':'Modo día'; }); }
 if(bar){ bar.querySelectorAll('.vbar__b button').forEach(function(b){ b.addEventListener('click',function(){ setV(b.parentElement.dataset.k,b.dataset.val,true); }); }); bar.querySelector('[data-close]').addEventListener('click',function(){ h.classList.add('vbar-off'); try{sessionStorage.setItem('h1-bar-alianzas','off')}catch(e){} window.dispatchEvent(new Event('resize')); }); pill.addEventListener('click',function(){ h.classList.remove('vbar-off'); try{sessionStorage.setItem('h1-bar-alianzas','on')}catch(e){} window.dispatchEvent(new Event('resize')); }); }
 // --- animaciones al entrar y al scrollear: lo que aparece sube y se enciende
 if(!matchMedia('(prefers-reduced-motion: reduce)').matches){ var SEL='.head,.big>div,.pv,.nc,.cv__it,.feat a,.hf__box,.quote,.aut>div,.vals>div,.curso,.prose>*,.stat>div,.news-item,.ng-main,.news-main,.tl__it,.phero h1,.phero .lead,.phero .crumb,.phero .pend,.chips-f,.form label,.faq details,.sf__head,.story__fix,.lightcount'; var rvs=[].slice.call(document.querySelectorAll(SEL)).filter(function(el){return !el.closest('.vbar')}); var byParent=new Map(); rvs.forEach(function(el){ var n=byParent.get(el.parentElement)||0; byParent.set(el.parentElement,n+1); el.classList.add('rv'); el.style.transitionDelay=((n%8)*70)+'ms'; }); var ro=new IntersectionObserver(function(es){ es.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add('in'); ro.unobserve(e.target); } }); },{threshold:.12,rootMargin:'0px 0px -5% 0px'}); rvs.forEach(function(el){ ro.observe(el); }); var chk=function(){ rvs.forEach(function(el){ if(el.classList.contains('in')) return; var r=el.getBoundingClientRect(); if(r.top<window.innerHeight*.95&&r.bottom>0) el.classList.add('in'); }); }; setTimeout(chk,80); var tk=false; window.addEventListener('scroll',function(){ if(tk) return; tk=true; requestAnimationFrame(function(){ chk(); tk=false; }); },{passive:true}); }
 // --- menú para celular
 var bg=document.getElementById('burger'); if(bg){ bg.addEventListener('click',function(){ h.classList.toggle('menu-on'); }); document.querySelectorAll('.mnav a, .mnav__close').forEach(function(a){ a.addEventListener('click',function(){ h.classList.remove('menu-on'); }); }); }
 // --- barra superior
 var hd=document.querySelector('header'); var last=0;
 function onS(){ if(h.classList.contains('menu-on')) return; var y=window.scrollY; if(y>120 && y>last+4) hd.classList.add('hide'); else if(y<last-4||y<=120) hd.classList.remove('hide'); last=y; }
 window.addEventListener('scroll',onS,{passive:true});
 // --- banner que se arma y se va
 var ld=document.getElementById('loader'); if(ld) setTimeout(function(){ld.classList.add('off')},2100);
 // --- datos grandes, suben despacio
 var fmt=function(n){return Math.round(n).toLocaleString('es-AR')};
 var io=new IntersectionObserver(function(es){ es.forEach(function(e){ var el=e.target, t=+el.dataset.count, b=el.querySelector('b'), pre=el.dataset.prefix||'', suf=el.dataset.suffix||''; el.__run=(el.__run||0)+1; var my=el.__run; if(!e.isIntersecting){ b.textContent=pre+fmt(0)+suf; return; } var t0=performance.now(); (function tick(now){ if(el.__run!==my) return; var k=Math.max(0,Math.min(1,(now-t0)/3200)); var v=t*(1-Math.pow(1-k,3)); b.textContent=pre+fmt(v)+suf; if(k<1) requestAnimationFrame(tick); })(t0); }); },{threshold:.5});
 document.querySelectorAll('[data-count]').forEach(function(el){io.observe(el)});
 // --- historia contada con scroll
 var steps=[].slice.call(document.querySelectorAll('.step'));
 if(steps.length){ var so=new IntersectionObserver(function(es){es.forEach(function(e){ if(e.isIntersecting){ var box=e.target.closest('[data-story]'); box.querySelectorAll('.step').forEach(function(s){s.classList.remove('on')}); e.target.classList.add('on'); var i=+e.target.dataset.ph; box.querySelectorAll('[data-ph-img]').forEach(function(p,j){p.classList.toggle('on',j===i)}); } });},{rootMargin:'-42% 0px -42% 0px',threshold:0}); steps.forEach(function(s){so.observe(s)}); }
 // --- programas: en pantallas táctiles, un toque da vuelta la tarjeta
 document.querySelectorAll('.pv').forEach(function(c){ c.addEventListener('click',function(e){ if(matchMedia('(hover:none)').matches){ e.preventDefault(); c.classList.toggle('flip'); } }); });
 // --- convenios: carrusel con flechas y avance automático
 var trs=[].slice.call(document.querySelectorAll('[data-cv-track]')); if(trs.length){ trs.forEach(function(tr){ var its=[].slice.call(tr.children); if(its.length>2){ its.forEach(function(it){ var c=it.cloneNode(true); c.setAttribute('data-clon',''); tr.appendChild(c); }); } }); var vis=function(){ return trs.filter(function(x){return x.offsetParent!==null})[0]; }; var step=function(tr){ var it=tr.querySelector('.cv__it'); return it?it.getBoundingClientRect().width+20:400; }; var setW=function(tr){ var n=tr.querySelectorAll('.cv__it:not([data-clon])').length; return n*step(tr); }; var norm=function(tr){ var w=setW(tr); if(!tr.querySelector('[data-clon]')) return; var sb=tr.style.scrollBehavior; tr.style.scrollBehavior='auto'; if(tr.scrollLeft>=w-2) tr.scrollLeft-=w; else if(tr.scrollLeft<0) tr.scrollLeft+=w; tr.style.scrollBehavior=sb; }; var mover=function(tr,dir){ if(dir<0 && tr.scrollLeft<step(tr)/2 && tr.querySelector('[data-clon]')){ var sb=tr.style.scrollBehavior; tr.style.scrollBehavior='auto'; tr.scrollLeft+=setW(tr); tr.style.scrollBehavior=sb; } tr.scrollBy({left:step(tr)*dir,behavior:'smooth'}); setTimeout(function(){norm(tr)},700); }; document.querySelectorAll('[data-cv]').forEach(function(b){ b.addEventListener('click',function(){ var tr=vis(); if(tr) mover(tr,+b.dataset.cv); }); }); var hov=false; trs.forEach(function(tr){ tr.addEventListener('pointerenter',function(){hov=true}); tr.addEventListener('pointerleave',function(){hov=false}); tr.addEventListener('scroll',function(){ clearTimeout(tr.__nt); tr.__nt=setTimeout(function(){norm(tr)},150); },{passive:true}); }); setInterval(function(){ var tr=vis(); if(!tr||hov||window.__alPausa) return; mover(tr,1); },6000);
   // cada tarjeta va pasando sus fotos
   var phs=[].slice.call(document.querySelectorAll('[data-cv-ph]')); setInterval(function(){ phs.forEach(function(ph){ var im=[].slice.call(ph.querySelectorAll('[data-cv-img]')); if(im.length<2) return; var k=im.findIndex(function(i){return i.classList.contains('on')}); var n=(k+1)%im.length; im.forEach(function(i,j){i.classList.toggle('on',j===n)}); var d=ph.querySelectorAll('.cv__dots i'); d.forEach(function(x,j){x.classList.toggle('on',j===n)}); }); },3500); }
 // --- lo que estamos haciendo: tarjetas con recorrido adentro
 var cst=document.querySelector('[data-cst]'); if(cst){ var track=cst.querySelector('.cst__track'), cards=[].slice.call(cst.querySelectorAll('[data-cst-card]')), m=cards.length, n=parseInt(cst.style.getPropertyValue('--n'),10)||3; var cstPaint=function(){ var vh=window.innerHeight, r=cst.getBoundingClientRect(); var s=Math.max(0,-r.top)/vh; var S=n*.55, T=.6, U=S+T; var k=Math.min(m-1,Math.floor(s/U)); var local=s-k*U; var off=0, idx; if(local<S||k===m-1){ var f=Math.min(local,S)/S, wts=[], tot=0, acc=0; for(var q=0;q<n;q++){ wts.push((q===0||q===n-1)?1:1.7); tot+=wts[q]; } idx=n-1; for(var q=0;q<n;q++){ acc+=wts[q]/tot; if(f<acc){ idx=q; break; } } } else { idx=n-1; off=Math.min(1,(local-S)/T); } var ch=cards[0].getBoundingClientRect().height+42; track.style.transform='translateY('+(-(k+off)*ch)+'px)'; cards.forEach(function(card,ci){ var ii=ci<k?n-1:(ci>k?0:idx); card.querySelectorAll('.cs__step').forEach(function(st,i){ st.classList.toggle('on',i===ii); st.classList.toggle('past',i<ii); }); var phs=card.querySelectorAll('[data-cs-ph]'); phs.forEach(function(ph,i){ ph.classList.toggle('on',i===Math.min(phs.length-1,ii)); }); card.querySelectorAll('.cs__dots i').forEach(function(d,i){ d.classList.toggle('on',i===ii); }); card.classList.toggle('last',ii===n-1); }); }; window.addEventListener('scroll',cstPaint,{passive:true}); window.addEventListener('resize',cstPaint); cstPaint(); }
 // --- segunda silueta de la P sólo cuando la sección es alta (en secciones cortas se encimarían)
 var podar=function(){ [].slice.call(document.querySelectorAll('.pbg--2,[data-pbg2]')).forEach(function(s){ s.setAttribute('data-pbg2','1'); var alta=s.offsetHeight>window.innerHeight*1.4; s.classList.toggle('pbg--2',alta); s.classList.toggle('pbg--left',!alta && s.id==='programas'); }); }; podar(); window.addEventListener('load',podar); window.addEventListener('resize',podar);
 // --- la silueta de la P sigue de largo cuando dos secciones seguidas tienen el mismo fondo
 var hasP=function(s){ return /\b(pbg|pline)\b/.test(s.className); };
 var rebands=function(){ [].slice.call(document.querySelectorAll('.band')).forEach(function(b){ while(b.firstChild) b.parentNode.insertBefore(b.firstChild,b); b.parentNode.removeChild(b); }); var root=document.querySelector('main')||document.body, bodyBg=getComputedStyle(document.body).backgroundColor, run=[], col=null; var flush=function(){ if(run.filter(function(x){return x.__vis;}).length>1){ var band=document.createElement('div'); band.className='band'; band.style.background=col; run[0].parentNode.insertBefore(band,run[0]); run.forEach(function(x){ band.appendChild(x); }); if(band.offsetHeight>window.innerHeight*1.6) band.classList.add('band--2'); } run=[]; col=null; }; [].slice.call(root.children).forEach(function(el){ if(el.tagName!=='SECTION'){ flush(); return; } var cs=getComputedStyle(el); if(cs.display==='none'){ el.__vis=false; if(run.length) run.push(el); return; } el.__vis=true; if(!hasP(el)||cs.backgroundImage!=='none'){ flush(); return; } var c=cs.backgroundColor; if(c==='rgba(0, 0, 0, 0)') c=bodyBg; if(run.length && c===col){ run.push(el); } else { flush(); run=[el]; col=c; } }); flush(); }; rebands(); window.__rebands=rebands;
 
 // --- enlaces a secciones: reubicar cuando terminó de cargar (las alturas cambian al cargar fotos y fuentes)
 // 02/11: sólo mientras la persona no tocó nada; en cuanto hace scroll, se deja de reubicar (antes la página volvía sola al inicio de la sección)
 if(location.hash){ var tocado=false; ['wheel','touchstart','keydown','pointerdown'].forEach(function(ev){ window.addEventListener(ev,function(){ tocado=true; },{passive:true}); }); var reubicar=function(){ if(tocado) return; var el; try{ el=document.querySelector(location.hash); }catch(e){ return; } if(el){ var y=Math.round(el.getBoundingClientRect().top+window.scrollY-20); if(Math.abs(y-window.scrollY)>2) window.scrollTo({top:y,behavior:'auto'}); } }; window.addEventListener('load',function(){ [60,600,1500,3000].forEach(function(ms){ setTimeout(reubicar,ms); }); }); if(document.readyState==='complete') setTimeout(reubicar,100); }
 // --- alianzas: "ver más" despliega el texto largo (y frena el pase automático mientras está abierto)
 document.querySelectorAll('[data-mas]').forEach(function(b){ b.addEventListener('click',function(){ var box=b.closest('.al__slide,.cv__it'); var on=box.classList.toggle('mas'); b.textContent=on?'Ver menos ←':'Ver más sobre esta alianza →'; window.__alPausa=on; }); });
 // --- alianzas: banner que pasa solo
 var al=document.querySelector('[data-al]'); if(al){ var sl=[].slice.call(al.querySelectorAll('[data-al-slide]')), dots=[].slice.call(al.querySelectorAll('[data-al-dots] i')), cur=0, pi=0, tm=null; var fotos=function(i){ return [].slice.call(sl[i].querySelectorAll('[data-al-ph]')); }; var go=function(i){ cur=(i+sl.length)%sl.length; pi=0; sl.forEach(function(s,k){ s.classList.toggle('on',k===cur); fotos(k).forEach(function(f,j){ f.classList.toggle('on',j===0); }); }); dots.forEach(function(d,k){d.classList.toggle('on',k===cur)}); }; var tick=function(){ if(window.__alPausa) return; var fs=fotos(cur); if(fs.length>1 && pi<fs.length-1){ pi++; fs.forEach(function(f,j){ f.classList.toggle('on',j===pi); }); } else go(cur+1); }; var arm=function(){ clearInterval(tm); tm=setInterval(tick,4500); }; dots.forEach(function(d,k){ d.addEventListener('click',function(){ go(k); arm(); }); }); [].forEach.call(al.querySelectorAll('[data-al-go]'),function(b){ b.addEventListener('click',function(){ go(cur+parseInt(b.getAttribute('data-al-go'),10)); arm(); }); }); arm(); }
 // --- línea de tiempo
 var tl=document.querySelector('.tl'); if(tl){ var its=[].slice.call(tl.querySelectorAll('.tl__it')); var near=function(){ var r=tl.getBoundingClientRect(); its.forEach(function(it){ var b=it.getBoundingClientRect(); it.classList.toggle('near',b.left>r.left-40&&b.right<r.right+40); }); }; tl.addEventListener('scroll',near,{passive:true}); near(); }
 // --- mapa que se enciende, con ficha
 var ter=document.getElementById('territorio'); if(ter){
   var svg=document.querySelector('#mapwrap svg'); var els=[].slice.call(svg.querySelectorAll('[id^="d-"]')).filter(function(el){return !/controno|division|caba/.test(el.id)});
   var fichaEl=document.getElementById('ficha');
   var paint=function(el,c){ el.querySelectorAll('polygon,path').forEach(function(p){p.style.fill=c}); if(el.tagName==='polygon') el.style.fill=c; };
   var lit=els.filter(function(el){return !!D[el.id.slice(2)]}).map(function(el){var b=el.getBBox();return {el:el,y:b.y+b.height/2}}).sort(function(a,b){return a.y-b.y}); var lc=document.getElementById('lc');
   var mo=new IntersectionObserver(function(es){es.forEach(function(e){ if(!e.isIntersecting) return; lit.forEach(function(o,i){setTimeout(function(){ paint(o.el,'#25B4BD'); lc.textContent=(i+1)+' distritos encendidos'; },i*16)}); mo.disconnect(); });},{threshold:.15}); mo.observe(document.getElementById('mapwrap')); if(h.getAttribute('data-mapa')!=='si'){ /* apagado: se enciende solo si se muestra */ }
   window.__lightMap=function(){ lit.forEach(function(o,i){setTimeout(function(){ paint(o.el,'#25B4BD'); lc.textContent=(i+1)+' distritos encendidos'; },i*16)}); };
   var sel=null;
   els.forEach(function(el){ var slug=el.id.slice(2); if(!D[slug]) return; el.classList.add('has'); el.addEventListener('click',function(){ var d=D[slug]; if(sel) sel.classList.remove('sel'); sel=el; el.classList.add('sel'); fichaEl.querySelector('h3').textContent=d.name; fichaEl.querySelector('small').textContent=d.programs.length+(d.programs.length===1?' programa':' programas'); fichaEl.querySelector('ul').innerHTML=d.programs.map(function(p){return '<li><b>'+p.name+'</b><span>'+p.desc+'</span></li>'}).join(''); var ph=fichaEl.querySelector('.ficha__ph'); if(d.img){ph.style.display='';ph.querySelector('img').src=d.img;} else ph.style.display='none'; fichaEl.classList.add('on'); }); });
 }
 // --- portada 1: video con el logo
 var vh=document.getElementById('inicio'); if(vh){
  var v=vh.querySelector('[data-vh-video]'), logo=vh.querySelector('[data-vh-logo]'), title=vh.querySelector('[data-vh-title]'), hint=vh.querySelector('[data-vh-hint]'), veil=vh.querySelector('[data-vh-veil]'), snd=vh.querySelector('[data-vh-snd]');
  var clamp=function(x,a,b){return Math.max(a,Math.min(b,x))}, seg=function(p,a,b){return clamp((p-a)/(b-a),0,1)};
  var progreso=function(){ var r=vh.getBoundingClientRect(); var rec=r.height-window.innerHeight; return rec<=0?0:clamp(-r.top/rec,0,1); };
  var pintar=function(){ var p=progreso(); logo.style.opacity=String(1-seg(p,0,.35)); logo.style.transform='translateY('+(-40*seg(p,0,.35))+'px) scale('+(1-.15*seg(p,0,.35))+')'; hint.style.opacity=String(1-seg(p,0,.15)); var t=seg(p,.3,.6); title.style.opacity=String(t); title.style.transform='translateY('+(24*(1-t))+'px)'; veil.style.background='linear-gradient(180deg,rgba(11,42,31,'+(.35+.1*t)+'),rgba(11,42,31,'+(.55+.3*t)+'))'; };
  window.addEventListener('scroll',pintar,{passive:true}); window.addEventListener('resize',pintar); pintar();
  setInterval(function(){ if(v.paused && vh.offsetParent!==null) v.play().catch(function(){}); },1500);
  var setSound=function(on){ v.muted=!on; snd.classList.toggle('sound',on); snd.querySelector('span').textContent=on?'Silenciar':'Activar sonido'; if(on) v.play().catch(function(){ v.muted=true; snd.classList.remove('sound'); snd.querySelector('span').textContent='Activar sonido'; }); };
  snd.addEventListener('click',function(e){ e.stopPropagation(); setSound(v.muted); });
 }
 // --- portada 6: frase que cambia al bajar sobre fotos de chicos
 var pa=document.getElementById('frase'); if(pa){
  var phs=[].slice.call(pa.querySelectorAll('[data-pa-ph]')), pls=[1,2].map(function(n){return pa.querySelector('[data-pa-line="'+n+'"]')}), pend=pa.querySelector('[data-pa-end]');
  var c3=function(x,a,b){return Math.max(a,Math.min(b,x))}, s3=function(p,a,b){return c3((p-a)/(b-a),0,1)};
  var paint3=function(){ var r=pa.getBoundingClientRect(); var rec=r.height-window.innerHeight; var p=rec<=0?0:c3(-r.top/rec,0,1); var ws=[[0,.36],[.36,.72]]; pls.forEach(function(el,i){ var a=ws[i][0],b=ws[i][1]; var inn=s3(p,a,a+.06), out=s3(p,b-.05,b); el.style.opacity=inn*(1-out); el.style.transform='translateY('+(-16*(1-inn)+10*out)+'px)'; }); var idx=p<.36?0:(p<.72?1:2); phs.forEach(function(ph,i){ph.classList.toggle('on',i===idx)}); var e=s3(p,.74,.9); pend.style.opacity=String(e); pend.classList.toggle('on',p>.85); };
  window.addEventListener('scroll',paint3,{passive:true}); window.addEventListener('resize',paint3); paint3();
 }
 // --- portada 4: logo quieto; al bajar aparece el video, después las frases, al final la frase que se escribe
 var qt=document.getElementById('quieto'); if(qt){
  var qv=qt.querySelector('[data-qt-video]'), ql=qt.querySelector('[data-qt-logo]'), qh=qt.querySelector('[data-qt-hint]'), qveil=qt.querySelector('[data-qt-veil]'), qcover=qt.querySelector('[data-qt-cover]'), qend=qt.querySelector('[data-qt-end]'), qtyped=qt.querySelector('[data-qt-typed]');
  var qlines=[1,2,3].map(function(n){return qt.querySelector('[data-qt-line="'+n+'"]')});
  var FR='una oportunidad que lo cambia todo'; var started=false;
  var c2=function(x,a,b){return Math.max(a,Math.min(b,x))}, s2=function(p,a,b){return c2((p-a)/(b-a),0,1)};
  var prog2=function(){ var r=qt.getBoundingClientRect(); var rec=r.height-window.innerHeight; return rec<=0?0:c2(-r.top/rec,0,1); };
  var paint2=function(){ var p=prog2();
    var f=s2(p,0,.16); ql.style.opacity=String(1-f); ql.style.transform='translateY('+(-60*f)+'px) scale('+(1-.25*f)+')'; qh.style.opacity=String(1-s2(p,0,.08));
    var vin=s2(p,.06,.2); qcover.style.opacity=String(1-vin); qveil.style.opacity=String(vin); if(qv.paused && qt.offsetParent!==null) qv.play().catch(function(){});
    var ws=[[.24,.4],[.4,.56],[.56,.72]]; qlines.forEach(function(el,i){ var a=ws[i][0],b=ws[i][1]; var inn=s2(p,a,a+.04), out=s2(p,b-.03,b); el.style.opacity=inn*(1-out); el.style.transform='translateY('+(-18*(1-inn)+10*out)+'px)'; });
    var t=s2(p,.74,.92); qend.style.opacity=String(t>0?1:0); var n=Math.round(FR.length*t); qtyped.textContent=FR.slice(0,n).replace(/^una oportunidad /,'una oportunidad\n'); var on=p>.93; qend.classList.toggle('on',on);
  };
  qtyped.style.whiteSpace='pre-line';
  window.addEventListener('scroll',paint2,{passive:true}); window.addEventListener('resize',paint2); paint2();
 }
})();

;

(function(){
  var intro=document.getElementById('intro'); if(document.documentElement.getAttribute('data-sinvideo')==='1'){ var _v=intro.querySelector('video'); if(_v){ _v.preload='none'; [].slice.call(_v.querySelectorAll('source')).forEach(function(s){s.remove();}); _v.removeAttribute('autoplay'); try{_v.load();}catch(e){} } }; if(!intro) return;
  try{ history.scrollRestoration='manual'; }catch(e){}
  if(!/p=/.test(location.hash)) window.scrollTo(0,0);
  var q=function(sel){return intro.querySelector(sel)};
  var mask=q('[data-mask]'), logo=q('[data-logo]'), pP=q('[data-p]'), pT=q('[data-turq]'), word=q('[data-word]'), scrim=q('[data-scrim]'), hint=q('[data-hint]'), end=q('[data-end]'), video=q('[data-video]'), bg=q('.intro__bg'), snd=q('[data-snd]');
  var lines=[1,2].map(function(n){return q('[data-line="'+n+'"]')});
  var ready=false, dur=0, released=false, wantSound=sessionStorage.getItem('fbp-sound')!=='off', idleT=null, lastP=-1;
  var REL=.18, T_REL=0;
  function onMeta(){ ready=true; dur=video.duration||0; }
  video.addEventListener('loadedmetadata',onMeta); if(video.readyState>=1) onMeta(); video.load();
  video.addEventListener('pause',function(){ if(released && !video.ended && progreso()>=REL){ if(!video.muted){ video.muted=true; snd.classList.remove('sound'); snd.querySelector('span').textContent='Activar sonido'; } video.play().catch(function(){}); } });
  video.addEventListener('ended',function(){ if(released){ video.currentTime=0; video.play().catch(function(){}); } });
  var clamp=function(v,a,b){return Math.max(a,Math.min(b,v))}, ease=function(t){return t<.5?2*t*t:-1+(4-2*t)*t}, seg=function(p,a,b){return clamp((p-a)/(b-a),0,1)};
  function progreso(){ if(window.__introFinal) return 1; var r=intro.getBoundingClientRect(); var rec=r.height-window.innerHeight; var p=rec<=0?0:clamp(-r.top/rec,0,1); if(window.__introDone) return .5+p*.5; return window.__introAuto||0; }
  function pw(){ return parseFloat(getComputedStyle(logo).width); }
  // sonido: los navegadores bloquean el audio automático; se activa en el primer toque/clic y con el botón
  function setSound(on){ wantSound=on; video.muted=!on; sessionStorage.setItem('fbp-sound',on?'on':'off'); snd.classList.toggle('sound',on); snd.querySelector('span').textContent=on?'Silenciar':'Activar sonido'; if(on&&released){ video.play().catch(function(){ video.muted=true; snd.classList.remove('sound'); snd.querySelector('span').textContent='Activar sonido'; }); } }
  snd.addEventListener('click',function(e){ e.stopPropagation(); setSound(video.muted); });
  function firstGesture(){ if(released && wantSound && video.muted) setSound(true); }
  ['pointerdown','touchend','keydown'].forEach(function(ev){ window.addEventListener(ev,firstGesture,{passive:true}); });
  // cierre: si nadie se mueve 5 s, se atenúa; vuelve con cualquier movimiento
  function wake(){ end.classList.remove('idle'); clearTimeout(idleT); if(end.classList.contains('on')) idleT=setTimeout(function(){ end.classList.add('idle'); },5000); }
  ['mousemove','touchstart','keydown','scroll','pointerdown'].forEach(function(ev){ window.addEventListener(ev,wake,{passive:true}); });
  function pintar(){
    var p=progreso();
    if(p>=REL && !released){ released=true; video.muted=true; video.play().catch(function(){}); snd.classList.add('on'); snd.classList.remove('sound'); snd.querySelector('span').textContent='Activar sonido'; }
    if(p<REL && released){ released=false; video.pause(); snd.classList.remove('on'); }
    if(released && video.paused && ready){ video.play().catch(function(){}); }
    var W=pw(); var shift0=W*(112-30)/60;
    var f1=ease(seg(p,0,.18));
    logo.style.setProperty('--shift',(shift0*(1-f1)).toFixed(1)+'px');
    var fw=ease(seg(p,0,.2)); word.style.opacity=String(1-seg(p,.15,.2)); word.style.transform='translateX('+(fw*window.innerWidth*0.85).toFixed(1)+'px)';
    hint.style.opacity=String(1-seg(p,0,.07));
    var f2=ease(seg(p,.18,.5));
    var vmax=Math.max(window.innerWidth,window.innerHeight);
    var size=W+(3.4*vmax-W)*f2;
    mask.style.webkitMaskSize=size+'px auto'; mask.style.maskSize=size+'px auto';
    mask.style.opacity=String(seg(p,.18,.24)); bg.style.opacity=String(1-seg(p,.22,.42));
    pP.style.opacity=String(0.85*(1-seg(p,.18,.34)));
    pT.style.transform='scale('+(size/W).toFixed(3)+')'; pT.style.opacity=String(1-seg(p,.18,.3));
    if(!released && ready && video.currentTime>0.05){ video.currentTime=0; }
    var ws=[[.56,1.2],[.66,1.2]];
    lines.forEach(function(el,i){ var a=ws[i][0],b=ws[i][1]; var inn=seg(p,a,a+.035), out=seg(p,b-.03,b); el.style.opacity=inn*(1-out); el.style.transform='translateY('+(-18*(1-inn)+10*out)+'px)'; });
    var c=seg(p,.78,.9); scrim.style.opacity=String(0.1+0.4*c);
    var endin=q('[data-endin]'), endlogo=q('[data-endlogo]'); endin.style.opacity=String(c); endin.style.transform='translateY('+(24*(1-c))+'px)'; endlogo.style.opacity=String(c);
    var on=c>.9; if(on!==end.classList.contains('on')){ end.classList.toggle('on',on); wake(); } if(on && !window.__introFinal && window.__introDone){ window.__introFinal=true; try{ sessionStorage.setItem('h1-intro-final',String(Date.now())); }catch(e){} } if(window.__introFinal && !intro.classList.contains('final') && intro.getBoundingClientRect().bottom < -10){ var ref=intro.nextElementSibling||document.body; var y0=ref.getBoundingClientRect().top; intro.classList.add('final'); var y1=ref.getBoundingClientRect().top; if(Math.abs(y1-y0)>1){ var H2=document.documentElement; var sb=H2.style.scrollBehavior; H2.style.scrollBehavior='auto'; window.scrollBy(0,y1-y0); H2.style.scrollBehavior=sb; } }
    lastP=p;
  }
  window.addEventListener('scroll',pintar,{passive:true}); window.addEventListener('resize',pintar); video.addEventListener('loadeddata',pintar); window.addEventListener('pageshow',pintar);
  setInterval(function(){ if(Math.abs(progreso()-lastP)>0.001 || (released && video.paused)) pintar(); },200); // red de seguridad: eventos perdidos o video detenido
  pintar();
  (function(){ var H=document.documentElement; var recarga=!!window.__recarga; if(recarga){ try{ sessionStorage.removeItem('h1-intro-vista'); sessionStorage.removeItem('h1-intro-final'); }catch(e){} try{ history.scrollRestoration='manual'; }catch(e){} window.scrollTo(0,0); window.addEventListener('load',function(){ if(!window.__introDone) window.scrollTo(0,0); }); } var vista=false, fin=false; try{ vista=(Date.now()-(parseInt(sessionStorage.getItem('h1-intro-vista'),10)||0))<1800000; fin=(Date.now()-(parseInt(sessionStorage.getItem('h1-intro-final'),10)||0))<1800000; }catch(e){} if(!recarga && fin){ window.__introDone=true; window.__introAuto=.5; window.__introFinal=true; intro.classList.add('final'); pintar(); return; } if(!recarga && (vista||location.hash||window.scrollY>10)){ window.__introDone=true; window.__introAuto=.5; pintar(); return; } H.classList.add('intro-lock'); window.scrollTo(0,0); var stop=function(e){ if(!window.__introDone) e.preventDefault(); }; window.addEventListener('wheel',stop,{passive:false}); window.addEventListener('touchmove',stop,{passive:false}); window.addEventListener('keydown',function(e){ if(!window.__introDone && [32,33,34,35,36,38,40].indexOf(e.keyCode)>=0) e.preventDefault(); }); window.addEventListener('scroll',function(){ if(!window.__introDone && window.scrollY>0) window.scrollTo(0,0); },{passive:true}); var t0=null; function step(ts){ if(!t0) t0=ts; var k=Math.min(1,(ts-t0)/3600); var e=k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2; window.__introAuto=.5*e; if(k>=1){ window.__introDone=true; H.classList.remove('intro-lock'); try{ sessionStorage.setItem('h1-intro-vista',String(Date.now())); }catch(e){} } pintar(); if(k<1) requestAnimationFrame(step); } setTimeout(function(){ requestAnimationFrame(step); },3000); })();
  var mh=/p=([\d.]+)/.exec(location.hash); if(mh){ var go=function(){ var rr=intro.getBoundingClientRect(); window.scrollTo(0,(rr.height-window.innerHeight)*parseFloat(mh[1])); }; go(); setTimeout(go,300); setTimeout(go,1500); }
})();
