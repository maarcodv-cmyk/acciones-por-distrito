
(function(){ try{ var nv=performance.getEntriesByType('navigation')[0]; var rl=nv?(nv.type==='reload'):(performance.navigation&&performance.navigation.type===1); if(rl){ history.scrollRestoration='manual'; window.__recarga=true; window.scrollTo(0,0); } }catch(e){} })();
(function(){ var p=new URLSearchParams(location.search), h=document.documentElement;
 var def={portada:'intro',historias:'cards',programas:'tarjetas',novedades:'lista',tono:'blanco',fondo:'silueta',datos:'liso',mapa:'no',linea:'no',respira:'no',boton:'si',banda:'si',buscando:'no',convenios:'banner',letras:'sombra',turquesa:'programas',altitulo:'arriba',menu:'formacion',bar:'1'};
 var ok={tono:['blanco','oscuro'],turquesa:['programas','novedades','alianzas'],menu:['formacion','separado'],convenios:['banner','tarjetas'],altitulo:['dentro','arriba'],letras:['sombra','relieve','oscurecer'],banda:['si','no'],linea:['si','no'],mapa:['si','no'],bar:['0','1']}; Object.keys(def).forEach(function(k){ var v=p.get(k); if(!v){ try{ v=sessionStorage.getItem('h1c-opt-'+k); }catch(e){} } if(v && !(ok[k]&&ok[k].indexOf(v)>=0)) v=null; h.setAttribute('data-'+k,v||def[k]); });
 try{ if(sessionStorage.getItem('h1-bar-alianzas')==='off') h.classList.add('vbar-off'); }catch(e){}
})();
