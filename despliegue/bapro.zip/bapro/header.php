<!doctype html>
<html <?php language_attributes(); ?><?php echo bapro_html_attrs(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class('inner'); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#contenido">Ir al contenido</a>
<header><div class="wrap"><a href="<?php echo esc_url(home_url('/')); ?>"><img class="logo" src="<?php echo BAPRO_TU; ?>/assets/logo.svg" alt="Fundación Banco Provincia"></a><nav><?php bapro_menu_links(); ?></nav><div class="hdr-r"><?php if (bapro_opt('modo_noche') === 'si') : ?><button class="theme" id="theme" type="button"><i></i><span>Modo noche</span></button><?php endif; ?><button class="burger" id="burger" type="button" aria-label="Menú"><i></i></button></div></div><nav class="mnav" id="mnav"><button class="mnav__close" type="button" aria-label="Cerrar el menú"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button><?php bapro_menu_links(); ?></nav></header>
<main id="contenido">
